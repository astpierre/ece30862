#ifndef BASE_H_
#define BASE_H_

class Base {
public:
   Base( );
   virtual ~Base( );

   virtual void f1( );
   virtual void f2( );
   void f3( );
   void f4( );
   void f5( );

   int i, j, k;

};
#endif /*BASE_H*/
