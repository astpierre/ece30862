#ifndef D1a_H_
#define D1a_H_

class D1a {
public:
   D1a( );
   virtual ~D1a( );

   virtual void f1( );
   virtual void f3( );
   void f4( );

   int i, j;

};
#endif /*D1a_H*/
