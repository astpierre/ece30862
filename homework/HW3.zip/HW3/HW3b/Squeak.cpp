#include <iostream>
#include <string>
#include "Squeak.h"

// PUT CODE HERE.  Use QuackQuack.cpp as an example
