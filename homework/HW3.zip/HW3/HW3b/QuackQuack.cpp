#include <iostream>
#include <string>
#include "QuackQuack.h"

QuackQuack::QuackQuack( ) { }

QuackQuack::~QuackQuack( ){ }

void QuackQuack::quack( ) {std::cout << "quack" << std::endl;}

