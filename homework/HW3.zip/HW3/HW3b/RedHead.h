#ifndef REDHEAD_H_
#define REDHEAD_H_
#include "Duck.h"
#include "FlyWithWings.h"
#include "QuackQuack.h"

class RedHead : public Duck {
public:

   RedHead( );
   virtual ~RedHead( );

};
#endif /* REDHEAD_H_ */
