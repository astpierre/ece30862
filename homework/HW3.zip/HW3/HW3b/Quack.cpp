#include <iostream>
#include <string>
#include "Quack.h"

Quack::Quack( ) { }

Quack::~Quack( ){ }

void Quack::quack( ) { }

