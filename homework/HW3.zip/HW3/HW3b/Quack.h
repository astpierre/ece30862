#ifndef QUACK_H_
#define QUACK_H_
#include <string>

class Quack {
public:

   Quack( );
   virtual ~Quack( );
   virtual void quack( );
};
#endif /* QUACK_H_ */
