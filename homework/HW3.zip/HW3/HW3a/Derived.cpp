#include "Derived.h"

Derived::Derived( ) { }
Derived::~Derived( ) { }

// add necessary functions here
